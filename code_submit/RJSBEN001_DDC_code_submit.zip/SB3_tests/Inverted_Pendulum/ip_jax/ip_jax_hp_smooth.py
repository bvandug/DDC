"""Hyperparameter tuning with stability-aware objective for JAX pendulum.

Extends the original tuning script by penalizing reward variance
to favor stable policies. Uses Optuna with SuccessiveHalvingPruner,
parallel trials, and JSON export of best results.
"""

import optuna
import sys
import numpy as np
import os, json, sys, torch, random
from torch import nn
from tqdm import tqdm
from stable_baselines3 import PPO, A2C, TD3, DDPG, SAC, DQN
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.noise import NormalActionNoise
from ip_jax_wrapper import InvertedPendulumGymWrapper, DiscretizedActionWrapper

TB_ROOT = "./jax_hp_smooth_logs"
os.makedirs(TB_ROOT, exist_ok=True)
TOTAL_TIMESTEPS = 100_000
EVAL_INTERVAL = 10_000
N_EVAL_EPISODES = 10
HARD_FAIL_THRESHOLDS = {20_000: 20, 30_000: 50}
MIN_RESOURCES = 40000
REDUCTION_FACTOR = 2
MIN_EARLY_STOPPING_RATE = 0


def set_global_seeds(seed: int = 42):
    """Set global seeds for reproducibility across NumPy, random, and Torch.

    Args:
        seed (int): Random seed value (default=42).
    """
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)

def make_env(algo_name):
    """Build a monitored DummyVecEnv for the selected algorithm.

    Wraps `InvertedPendulumGymWrapper` and discretizes actions for DQN
    using torque values [-10, 0, 10] for better exploration stability.

    Args:
        algo_name (str): RL algorithm name ("ppo", "td3", etc.).

    Returns:
        DummyVecEnv: Vectorized environment ready for SB3 training.
    """
    base = InvertedPendulumGymWrapper(seed=42)
    if algo_name == "dqn":
        return DummyVecEnv([lambda: Monitor(DiscretizedActionWrapper(base, [-10.0, 0.0, 10.0]))])
    return DummyVecEnv([lambda: Monitor(base)])

def objective(trial, algo_name):
    """Optuna objective function with stability-aware reward.

    Trains the model for fixed intervals, evaluates on 10 episodes,
    computes a stability-adjusted reward = mean_reward - α·std_reward,
    and reports it to Optuna for pruning decisions.

    Args:
        trial (optuna.Trial): Trial object for suggesting parameters.
        algo_name (str): Algorithm being tuned.

    Returns:
        float: Stability-adjusted reward (higher = better stability).

    Raises:
        optuna.TrialPruned: When reward falls below thresholds or
        Optuna decides the trial is unpromising.
    """
    set_global_seeds(42)
    env = make_env(algo_name)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    activation_map = {"tanh": nn.Tanh, "relu": nn.ReLU, "leaky_relu": nn.LeakyReLU, "elu": nn.ELU}

    def policy_kwargs_from_trial(trial):
        return {
            "net_arch": [trial.suggest_int("layer_size", 32, 512)] * trial.suggest_int("n_layers", 1, 4),
            "activation_fn": activation_map[trial.suggest_categorical("activation_fn", list(activation_map.keys()))]
        }

    if algo_name == "ppo":
        n_steps = trial.suggest_categorical("n_steps", [64, 128, 256, 512, 1024, 2048])
        batch_size = trial.suggest_categorical("batch_size", [32, 64, 128, 256, 512])
        if batch_size > n_steps or n_steps % batch_size != 0:
            print(f"Pruning trial {trial.number}: batch_size={batch_size} incompatible with n_steps={n_steps}", flush=True)
            raise optuna.TrialPruned()
        params = {
            "learning_rate": trial.suggest_float("learning_rate", 2e-4, 2e-3, log=True),
            "n_steps": n_steps, "batch_size": batch_size,
            "n_epochs": trial.suggest_int("n_epochs", 4, 20),
            "gamma": trial.suggest_float("gamma", 0.9, 0.9999),
            "clip_range": trial.suggest_float("clip_range", 0.1, 0.4),
            "ent_coef": trial.suggest_float("ent_coef", 1e-8, 0.1, log=True),
            "vf_coef": trial.suggest_float("vf_coef", 0.1, 1.0),
            "max_grad_norm": trial.suggest_float("max_grad_norm", 0.3, 5.0),
            "gae_lambda": trial.suggest_float("gae_lambda", 0.8, 1.0),
        }
        model = PPO("MlpPolicy", env, device=device, verbose=0, tensorboard_log=os.path.join(TB_ROOT, algo_name),
                    policy_kwargs=policy_kwargs_from_trial(trial), **params)

    elif algo_name == "a2c":
        params = {
            "learning_rate": trial.suggest_float("learning_rate", 1e-5, 1e-3, log=True),
            "gamma": trial.suggest_float("gamma", 0.90, 0.9999),
            "n_steps": trial.suggest_int("n_steps", 8, 2048, log=True),
            "ent_coef": trial.suggest_float("ent_coef", 1e-7, 0.1, log=True),
            "vf_coef": trial.suggest_float("vf_coef", 0.1, 1.0),
            "max_grad_norm": trial.suggest_float("max_grad_norm", 0.3, 5.0),
            "rms_prop_eps": trial.suggest_float("rms_prop_eps", 1e-6, 1e-3, log=True),
            "use_rms_prop": trial.suggest_categorical("use_rms_prop", [True, False]),
        }
        model = A2C("MlpPolicy", env, device=device, verbose=0, tensorboard_log=os.path.join(TB_ROOT, algo_name),
                    policy_kwargs=policy_kwargs_from_trial(trial), **params)

    elif algo_name in ["td3", "ddpg"]:
        params = {
            "learning_rate": trial.suggest_float("learning_rate", 1e-5, 1e-3, log=True),
            "buffer_size": trial.suggest_int("buffer_size", 50_000, 200_000),
            "batch_size": trial.suggest_int("batch_size", 64, 512),
            "tau": trial.suggest_float("tau", 0.001, 0.02),
            "gamma": trial.suggest_float("gamma", 0.9, 0.9999),
            "train_freq": (1, "episode"),
            "gradient_steps": -1,
        }
        action_noise = NormalActionNoise(mean=np.zeros(1), sigma=trial.suggest_float("action_noise_sigma", 0.1, 0.5) * np.ones(1))
        model_class = TD3 if algo_name == "td3" else DDPG
        model = model_class("MlpPolicy", env, device=device, verbose=0, tensorboard_log=os.path.join(TB_ROOT, algo_name),
                    policy_kwargs=policy_kwargs_from_trial(trial), **params)

    elif algo_name == "sac":
        params = {
            "learning_rate": trial.suggest_float("learning_rate", 1e-5, 1e-3, log=True),
            "buffer_size": trial.suggest_int("buffer_size", 50_000, 200_000),
            "batch_size": trial.suggest_int("batch_size", 64, 512),
            "tau": trial.suggest_float("tau", 0.001, 0.02),
            "gamma": trial.suggest_float("gamma", 0.9, 0.9999),
            "ent_coef": trial.suggest_categorical("ent_coef", ["auto", 0.001, 0.01, 0.1]),
        }
        model = SAC("MlpPolicy", env, device=device, verbose=0, tensorboard_log=os.path.join(TB_ROOT, algo_name),
                    policy_kwargs=policy_kwargs_from_trial(trial), **params)

    elif algo_name == "dqn":
        params = {
            "learning_rate": trial.suggest_float("learning_rate", 2e-4, 2e-3, log=True),
            "buffer_size": trial.suggest_int("buffer_size", 50_000, 150_000),
            "batch_size": trial.suggest_int("batch_size", 32, 512, step=32),
            "gamma": trial.suggest_float("gamma", 0.95, 0.995),
            "tau": trial.suggest_float("tau", 0.01, 0.03),
            "exploration_fraction": trial.suggest_float("exploration_fraction", 0.15, 0.4),
            "exploration_final_eps": trial.suggest_float("exploration_final_eps", 0.01, 0.1),
            "target_update_interval": trial.suggest_int("target_update_interval", 1_000, 5_000),
            "train_freq": trial.suggest_int("train_freq", 1, 6),
        }
        model = DQN("MlpPolicy", env, device=device, verbose=0,tensorboard_log=os.path.join(TB_ROOT, algo_name),
                    learning_starts=5000,
                    policy_kwargs=policy_kwargs_from_trial(trial), **params)

    else:
        raise ValueError(f"Unsupported algorithm: {algo_name}")

    timesteps = 0
    while timesteps < TOTAL_TIMESTEPS:
        model.learn(EVAL_INTERVAL, reset_num_timesteps=False, progress_bar=False, tb_log_name=f"T{trial.number}")
        timesteps += EVAL_INTERVAL

        rewards = []
        for _ in range(N_EVAL_EPISODES):
            obs = env.reset()
            done, ep_rew = False, 0.0
            while not done:
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, done, _ = env.step(action)
                ep_rew += reward[0] if isinstance(reward, (list, np.ndarray)) else reward
            rewards.append(ep_rew)

        rewards = np.array(rewards)
        mean_reward = float(np.mean(rewards))
        std_reward = float(np.std(rewards))

        # Stability-aware reward with a penalty term
        alpha = 0.25  # adjust this to weigh variance penalty more/less
        stability_reward = mean_reward - alpha * std_reward

        # Logging for diagnostics
        top_k_avg = float(np.mean(sorted(rewards, reverse=True)[:8]))
        model.logger.record("eval/top8_avg", top_k_avg)
        model.logger.record("eval/mean_all10", mean_reward)
        model.logger.record("eval/std_all10", std_reward)
        model.logger.record("eval/stability_reward", stability_reward)
        model.logger.dump(timesteps)

        # Early pruning logic remains the same
        if timesteps in HARD_FAIL_THRESHOLDS and top_k_avg < HARD_FAIL_THRESHOLDS[timesteps]:
            print(f"Pruning trial {trial.number}: reward {top_k_avg:.2f} below threshold {HARD_FAIL_THRESHOLDS[timesteps]} at {timesteps} steps", flush=True)
            raise optuna.TrialPruned()

        trial.report(stability_reward, step=timesteps)
        if trial.should_prune():
            print(f"Pruning trial {trial.number}: Optuna judged it underperforming at step {timesteps} with reward {stability_reward:.2f}", flush=True)
            raise optuna.TrialPruned()

    return stability_reward


def tune_hyperparameters(algo_name, n_trials=50, n_parallel=4):
    """Run Optuna study for a single algorithm with smooth objective.

    Creates or loads a study, runs parallel trials, displays progress
    with a live tqdm bar, and saves the best parameters/results to disk.

    Args:
        algo_name (str): Algorithm to tune.
        n_trials (int): Number of trials (default=50).
        n_parallel (int): Number of parallel jobs (default=4).

    Returns:
        dict: Dictionary of best hyperparameters and metadata.
    """
    print(f"Tuning {algo_name.upper()} on JAX env with SB3...")
    storage_path = f"sqlite:///jax_optuna_smooth_{algo_name}.db"
    study = optuna.create_study(direction="maximize",
        pruner=optuna.pruners.SuccessiveHalvingPruner(
            min_resource=MIN_RESOURCES,
            reduction_factor=REDUCTION_FACTOR,
            min_early_stopping_rate=MIN_EARLY_STOPPING_RATE),
        study_name=f"jax_{algo_name}_tuning",
        storage=storage_path,
        load_if_exists=True)

    pbar = tqdm(total=n_trials, desc=f"Tuning {algo_name.upper()}", file=sys.stdout, dynamic_ncols=True)
    def _cb(st, tr):
        pbar.update(1)
        try: 
            pbar.set_postfix(best_val=f"{st.best_value:.1f}")
        except: 
            pbar.set_postfix(best_val="–")
        sys.stdout.write("\n")  # Add newline after Optuna's output
        sys.stdout.flush()
    study.optimize(lambda t: objective(t, algo_name), n_trials=n_trials, n_jobs=n_parallel, callbacks=[_cb])
    pbar.close()

    os.makedirs("jax_hp_smooth_results", exist_ok=True)
    with open(f"jax_hp_smooth_results/{algo_name}_best_params.json", "w") as f:
        json.dump({"best_params": study.best_params, "best_value": study.best_value, "n_trials": n_trials}, f, indent=4)

    print(f"Best reward: {study.best_value:.2f}")
    for k, v in study.best_params.items():
        print(f"  {k}: {v}")
    return study.best_params

if __name__ == "__main__":
    """CLI entry point.

    Tunes a fixed subset of algorithms (currently PPO only) and
    writes best parameters with stability-aware objective to JSON.
    """
    for algo in [ "ppo"]: #enter the algo names you want to tune here #["ppo", "td3", "ddpg", "sac", "dqn", "a2c"]
        tune_hyperparameters(algo)
